<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Recinto extends Model
{
    public function especies()
    {
        return $this->belongsToMany(Especie::class);
    }

    public function animales()
    {
        return $this->hasMany(Animal::class);
    }
}
