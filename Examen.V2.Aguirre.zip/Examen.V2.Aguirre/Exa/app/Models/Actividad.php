<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Actividad extends Model
{
    public function animales()
    {
        return $this->belongsToMany(Animal::class);
    }
}
