<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Animal extends Model
{
    public function especie()
    {
        return $this->belongsTo(Especie::class, 'especie_id');
    }

    public function recinto()
    {
        return $this->belongsTo(Recinto::class, 'recinto_id');
    }

    public function cuidador()
    {
        return $this->belongsTo(Cuidador::class, 'cuidador_id');
    }

    public function actividades()
    {
        return $this->belongsToMany(Actividad::class);
    }
}