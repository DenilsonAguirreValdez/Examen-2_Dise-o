<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Animal;

class AnimalController extends Controller
{
    public function index()
    {
        $animales = Animal::all();
        return response()->json($animales);
    }

    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string',
            'especie_id' => 'required|exists:especies,id'
        ]);

        $animal = Animal::create($request->all());

        return response()->json($animal, 201);
    }

    public function show($id)
    {
        $animal = Animal::findOrFail($id);
        return response()->json($animal);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'nombre' => 'required|string',
            'especie_id' => 'required|exists:especies,id'
        ]);

        $animal = Animal::findOrFail($id);
        $animal->update($request->all());

        return response()->json($animal, 200);
    }

    public function destroy($id)
    {
        $animal = Animal::findOrFail($id);
        $animal->delete();

        return response()->json(null, 204);
    }
}

