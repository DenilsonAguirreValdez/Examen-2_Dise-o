<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cuidador;

class CuidadorController extends Controller
{
    public function index()
    {
        $cuidadores = Cuidador::all();
        return response()->json($cuidadores);
    }

    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string',
        ]);

        $cuidador = Cuidador::create($request->all());

        return response()->json($cuidador, 201);
    }

    public function show($id)
    {
        $cuidador = Cuidador::with('animales')->findOrFail($id);
        return response()->json($cuidador);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'nombre' => 'required|string',
        ]);

        $cuidador = Cuidador::findOrFail($id);
        $cuidador->update($request->all());

        return response()->json($cuidador, 200);
    }

    public function destroy($id)
    {
        $cuidador = Cuidador::findOrFail($id);
        $cuidador->delete();

        return response()->json(null, 204);
    }
}
