<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Especie;

class EspecieController extends Controller
{
    public function index()
    {
        $especies = Especie::all();
        return response()->json($especies);
    }

    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string',
        ]);

        $especie = Especie::create($request->all());

        return response()->json($especie, 201);
    }

    public function show($id)
    {
        $especie = Especie::with('recintos', 'animales')->findOrFail($id);
        return response()->json($especie);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'nombre' => 'required|string',
        ]);

        $especie = Especie::findOrFail($id);
        $especie->update($request->all());

        return response()->json($especie, 200);
    }

    public function destroy($id)
    {
        $especie = Especie::findOrFail($id);
        $especie->delete();

        return response()->json(null, 204);
    }
}
