<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Recinto;

class RecintoController extends Controller
{
    public function index()
    {
        $recintos = Recinto::all();
        return response()->json($recintos);
    }

    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string',
        ]);

        $recinto = Recinto::create($request->all());

        return response()->json($recinto, 201);
    }

    public function show($id)
    {
        $recinto = Recinto::with('especies', 'animales')->findOrFail($id);
        return response()->json($recinto);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'nombre' => 'required|string',
        ]);

        $recinto = Recinto::findOrFail($id);
        $recinto->update($request->all());

        return response()->json($recinto, 200);
    }

    public function destroy($id)
    {
        $recinto = Recinto::findOrFail($id);
        $recinto->delete();

        return response()->json(null, 204);
    }
}
