<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Actividad;

class ActividadController extends Controller
{
    public function index()
    {
        $actividades = Actividad::all();
        return response()->json($actividades);
    }

    public function store(Request $request)
    {
        
        $request->validate([
            'nombre' => 'required|string',
            'dia' => 'required|string',
            'horario' => 'required|date_format:H:i'
        ]);

        $actividad = Actividad::create($request->all());

        return response()->json($actividad, 201);
    }

    public function show($id)
    {
        $actividad = Actividad::with('animales')->findOrFail($id);
        return response()->json($actividad);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'nombre' => 'required|string',
            'dia' => 'required|string',
            'horario' => 'required|date_format:H:i'
        ]);

        $actividad = Actividad::findOrFail($id);
        $actividad->update($request->all());

        return response()->json($actividad, 200);
    }

    public function destroy($id)
    {
        $actividad = Actividad::findOrFail($id);
        $actividad->delete();

        return response()->json(null, 204);
    }
}

