<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AnimalController;
use App\Http\Controllers\EspecieController;
use App\Http\Controllers\RecintoController;
use App\Http\Controllers\CuidadorController;
use App\Http\Controllers\ActividadController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// Rutas para el controlador Animal
Route::resource('animales', AnimalController::class);

// Rutas para el controlador Especie
Route::resource('especies', EspecieController::class);

// Rutas para el controlador Recinto
Route::resource('recintos', RecintoController::class);

// Rutas para el controlador Cuidador
Route::resource('cuidadores', CuidadorController::class);

// Rutas para el controlador Actividad
Route::resource('actividades', ActividadController::class);
