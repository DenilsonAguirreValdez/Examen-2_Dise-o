<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Models\Animal;

class AnimalApiTest extends TestCase
{
    use RefreshDatabase;

    /**
     * Verifica que la ruta /api/animales devuelve una respuesta exitosa.
     *
     * @return void
     */
    public function test_animal_list_endpoint_returns_successful_response()
    {
        $response = $this->get('/api/animales');

        $response->assertStatus(200);
    }

    /**
     * Verifica que la ruta /api/animales devuelve datos de animales en formato JSON.
     *
     * @return void
     */
    public function test_animal_list_endpoint_returns_animal_data()
    {
        // Creamos un animal de ejemplo en la base de datos
        Animal::factory()->create([
            'nombre' => 'León',
            'especie_id' => 1, // suponiendo que el ID de la especie del león es 1
        ]);

        // Realizamos una solicitud a la ruta /api/animales
        $response = $this->get('/api/animales');

        // Verificamos que la respuesta sea exitosa
        $response->assertStatus(200);

        // Verificamos que la respuesta contenga datos de animales en formato JSON
        $response->assertJsonFragment([
            'nombre' => 'León',
            'especie_id' => 1,
        ]);
    }
}

